package org.apache.jsp.include.user;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.naming.InitialContext;
import java.net.*;
import java.io.BufferedInputStream;
import java.io.*;
import java.util.*;
import org.json.JSONTokener;
import java.net.HttpURLConnection;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONStringer;
import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import com.genesyslab.studio.backendlogic.BackendLogManager;

public final class buildGrammar_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


Logger logger = BackendLogManager.getLogger("buildGrammar");

public String getXML(HttpServletRequest request, HttpServletResponse response){  
	String inTags = request.getParameter("tags");
	String outTags = "";
	List<String> items = Arrays.asList(inTags.split("\\s*,\\s*"));
	List<String> cleanList = new ArrayList<String>();
	
	for(String tag : items) {
		
		if(tag.equalsIgnoreCase("agent")) continue;
		if(tag.equalsIgnoreCase("back")) continue;
		
		if(!cleanList.contains(tag)) {
			cleanList.add(tag);
		}
	}
	
	for(String tag : cleanList) {
		String expandedWords = tag.replace("_"," ");
		outTags += "<item><tag>out='" + tag + "'</tag><one-of><item><token>" + expandedWords + "</token></item></one-of></item>";
	}
	return outTags;
}

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<grammar xmlns=\"http://www.w3.org/2001/06/grammar\" xml:lang=\"en-US\" root=\"globalOptions\" version=\"1.0\" mode=\"voice\">\n    <rule id=\"globalOptions\" scope=\"public\">\n        <one-of>\n            <item>\n                <tag>out='back'</tag>\n                <one-of>\n                    <item>\n                        <token>back</token>\n                    </item>\n                </one-of>\n            </item>\n            <item>\n                <tag>out='agent'</tag>\n                <one-of>\n                    <item>\n                        <token>agent</token>\n                    </item>\n                    <item>\n                        <token>operator</token>\n                    </item>\n                </one-of>\n            </item>\n            <item>\n                <tag>out='continue'</tag>\n                <one-of>\n                    <item>\n                        <token>next</token>\n                    </item>\n                </one-of>\n            </item>\n");
      out.write("            <item>\n                <tag>out='skip'</tag>\n                <one-of>\n                    <item>\n                        <token>skip</token>\n                    </item>\n                </one-of>\n            </item>\n            ");
 out.println(getXML(request, response)); 
      out.write("</one-of>\n    </rule>\n</grammar>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
